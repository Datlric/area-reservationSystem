create definer = root@localhost view `19级管院学生的选课情况` as
(
select `classdesign`.`学生`.`学号`   AS `学号`,
       `classdesign`.`学生`.`姓名`   AS `姓名`,
       `classdesign`.`班级`.`所属学院` AS `所属学院`,
       `classdesign`.`课程`.`课号`   AS `课号`,
       `classdesign`.`课程`.`课程名称` AS `课程名称`,
       `classdesign`.`课程`.`学时`   AS `学时`,
       `classdesign`.`课程`.`使用教材` AS `使用教材`,
       `classdesign`.`课程`.`课程级别` AS `课程级别`,
       `classdesign`.`课程`.`开设学院` AS `开设学院`
from `classdesign`.`选修`
         join `classdesign`.`学生`
         join `classdesign`.`课程`
         join `classdesign`.`班级`
where ((`classdesign`.`选修`.`学号` = `classdesign`.`学生`.`学号`) and (`classdesign`.`选修`.`课号` = `classdesign`.`课程`.`课号`) and
       (`classdesign`.`学生`.`班号` = `classdesign`.`班级`.`班号`) and (`classdesign`.`班级`.`所属学院` = '经济与管理学院')));

