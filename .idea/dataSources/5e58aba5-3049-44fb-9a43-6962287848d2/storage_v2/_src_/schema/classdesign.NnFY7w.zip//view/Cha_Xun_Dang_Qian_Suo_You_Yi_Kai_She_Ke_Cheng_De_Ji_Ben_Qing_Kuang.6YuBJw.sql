create definer = root@localhost view 查询当前所有已开设课程的基本情况 as
(
select `classdesign`.`授课`.`课号`   AS `课号`,
       `classdesign`.`课程`.`课程名称` AS `课程名称`,
       `classdesign`.`教师`.`姓名`   AS `教师姓名`,
       `classdesign`.`课程`.`使用教材` AS `使用教材`,
       `classdesign`.`课程`.`开设学院` AS `开设学院`,
       `classdesign`.`课程`.`课程级别` AS `课程级别`,
       `classdesign`.`课程`.`学时`   AS `学时`,
       `classdesign`.`授课`.`授课周数` AS `授课周数`
from `classdesign`.`授课`
         join `classdesign`.`课程`
         join `classdesign`.`教师`
where ((`classdesign`.`授课`.`课号` = `classdesign`.`课程`.`课号`) and
       (`classdesign`.`授课`.`教师编号` = `classdesign`.`教师`.`教师编号`)));

