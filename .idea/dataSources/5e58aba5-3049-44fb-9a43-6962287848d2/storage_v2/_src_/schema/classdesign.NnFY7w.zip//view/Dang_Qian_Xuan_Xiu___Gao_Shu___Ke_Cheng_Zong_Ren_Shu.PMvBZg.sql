create definer = root@localhost view 当前选修“高数”课程总人数 as
(
select count(`classdesign`.`选修`.`学号`) AS `选修“高数”课程人数`
from `classdesign`.`选修`
         join `classdesign`.`课程`
where ((`classdesign`.`选修`.`课号` = `classdesign`.`课程`.`课号`) and (`classdesign`.`课程`.`课程名称` = '高数')));

